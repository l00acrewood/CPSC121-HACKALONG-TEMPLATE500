[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=23304161)
# Lab exercise 7 objectives
1. Practice writing C++ classes that use shared pointers (`std::shared_ptr`).
2. Continued practice writing programs that use maps and vectors.
3. Implement programs that use class objects and class composition.


# Instructions
Answer the programming problems sequentially (i.e., answer prob01 before prob02). 
If you have questions let your instructor or the lab assistant know. You can also consult your classmates.

To get started on problem 1, change into the `prob01` directory. If you haven't already, change into the lab07 directory:
```
cd lab07-<YOUR_NAME>
```

Then change into the prob01 folder and view the README for its instructions:
```
cd prob01
```
