
from gggg import *

a = Assignment(17 , 4)
s = State(a)

horizontal_rule()

s.reject_if_file_unchanged('main.cc',
                           '3f6b531dbaf35004f7f995b0bb2f41d8651e67b684b88ec8e46b40e5875bb42c')
s.reject_if_file_unchanged('network.h',
                           '77762ae3ad89a9e1b6db9979a83a2f6bf4851ebbb39177f14df0e0168a36cf84')
s.reject_if_file_unchanged('phone.h',
                           '0fc8f4436cb4242ebea6585721ed68256f9f720fd3f2eb4bbe4b93b1070577e5')

s.reject_if_file_changed('message.h',
                         'b82c3a2d2e5c31f40ff4826b0dd58b3fa28c96bc518cebd3b7b3d72749160d39')
s.reject_if_file_changed('tools/settings/unittest.cc',
                         'b34158509ac904325f39df9af3808464738c996b26a2c76bc5583af5f4a4dffd')

s.gtest_run('tools/output/unittest')
s.gtest_suite_test('Phone', 5)
s.gtest_suite_test('Network', 5)
s.gtest_suite_test('Driver', 5)

s.clang_tidy_run("main.cc", "main", ["network.cc", "phone.cc"])
s.clang_tidy_check(1)

s.clang_format_run(["main.cc", "message.h", "network.cc", "network.h", "phone.cc", "phone.h"])
s.clang_format_check(1)

s.summarize()