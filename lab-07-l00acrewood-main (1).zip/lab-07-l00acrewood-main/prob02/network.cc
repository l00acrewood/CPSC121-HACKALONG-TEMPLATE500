// Please fill in below.
// Anthony L. Barbosa
// CPSC 121L-14
// 3/31/2026
// AnthonylBarbosa@csu.fullerton.edu
// l00acrewood

// ========================= YOUR CODE HERE =========================
// This implementation file (network.cc) is where you should implement
// the member functions declared in the header (network.h), only
// if you didn't implement them inline within network.h.
//
// Remember to specify the name of the class with :: in this format:
//     <return type> MyClassName::MyFunction() {
//        ...
//     }
// to tell the compiler that each function belongs to the Network class.
// ===================================================================
#include "network.h"

void Network::AddPhone(std::shared_ptr<Phone> phone) {
  phonebook_[phone->GetOwner()] = phone;
}

void Network::SendMessage(std::shared_ptr<Message> message,
                          const std::string& recipient) {
  auto it = phonebook_.find(recipient);
  if (it != phonebook_.end()) {
    it->second->AcceptMessage(message);
  }
}

void Network::SendMessage(std::shared_ptr<Message> message,
                          const std::vector<std::string>& recipients) {
  for (const auto& recipient : recipients) {
    SendMessage(message, recipient);
  }
}