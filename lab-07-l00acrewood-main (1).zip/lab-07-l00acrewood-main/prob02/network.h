// Please fill in below.
// Anthony L. Barbosa
// CPSC 121L-14
// 3/31/2026
// AnthonylBarbosa@csu.fullerton.edu
// l00acrewood
//
// Lab 9-2

#ifndef NETWORK_H
#define NETWORK_H

#include <map>
#include <memory>

#include "message.h"
#include "phone.h"

class Network {
  // ======================= YOUR CODE HERE =======================
  // Write the Network class here. Refer to the README for the member
  // variables, constructors, and member functions needed.
  //
  // If you were the "driver" for the Phone class, then switch roles
  // with your lab partner and act as the "navigator" for this class.
  // ===============================================================
 public:
  void AddPhone(std::shared_ptr<Phone> phone);
  void SendMessage(std::shared_ptr<Message> message,
                   const std::string& recipient);
  void SendMessage(std::shared_ptr<Message> message,
                   const std::vector<std::string>& recipients);

 private:
  std::map<std::string, std::shared_ptr<Phone>> phonebook_;
};

#endif