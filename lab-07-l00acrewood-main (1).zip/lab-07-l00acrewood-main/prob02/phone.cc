// Please fill in below.
// Anthony L. Barbosa
// CPSC 121L-14
// 3/31/2026
// AnthonylBarbosa@csu.fullerton.edu
// l00acrewood

// ========================= YOUR CODE HERE =========================
// This implementation file (phone.cc) is where you should implement
// the member functions declared in the header (phone.h), only
// if you didn't implement them inline within phone.h.
//
// Remember to specify the name of the class with :: in this format:
//     <return type> MyClassName::MyFunction() {
//        ...
//     }
// to tell the compiler that each function belongs to the Phone class.
// ===================================================================
#include "phone.h"