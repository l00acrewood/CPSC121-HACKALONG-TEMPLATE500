// Please fill in below.
// Anthony L. Barbosa
// CPSC 121L-14
// 3/31/2026
// AnthonylBarbosa@csu.fullerton.edu
// l00acrewood
//
// Lab 9-2

#ifndef PHONE_H
#define PHONE_H

#include <iostream>
#include <memory>
#include <vector>

#include "message.h"

class Phone {
  // ======================= YOUR CODE HERE =======================
  // Write the Phone class here. Refer to the README for the member
  // variables, constructors, and member functions needed.
  //
  // Select one among you and your lab partner to be the "driver"
  // and the other to be the "navigator". The driver should write
  // the code, while the navigator reviews the code. Both of you
  // should communicate and share thoughts as you go along.
  // ===============================================================
 public:
  Phone(const std::string& owner) : owner_(owner){};

  std::string GetOwner() const {
    return owner_;
  }

  std::shared_ptr<Message> AuthorMessage(const std::string& message) const {
    return std::make_shared<Message>(message, owner_);
  }

  void AcceptMessage(std::shared_ptr<Message> message) {
    messages_.push_back(message);
  }

  void PrintMessages() const {
    for (const auto& msg : messages_) {
      std::cout << msg->GetSender() << ": " << msg->GetMessage() << std::endl;
    }
  }

 private:
  std::string owner_;
  std::vector<std::shared_ptr<Message>> messages_;
};

#endif