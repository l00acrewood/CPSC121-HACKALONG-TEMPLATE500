// Please fill in below.
// Anthony L. Barbosa
// CPSC 121L-14
// 3/31/2026
// AnthonylBarbosa@csu.fullerton.edu
// l00acrewood

#include <iostream>

#include "foodpantry.h"
#include "volunteer.h"

int main() {
  Volunteer jc("JC");
  Volunteer paul("Paul");

  // =================== YOUR CODE HERE ===================
  // 2. Call CreatePantry, passing in "Tuffy's Pantry"
  //    and assign it to a shared_ptr named tuffys_pantry.
  std::shared_ptr<FoodPantry> tuffys_pantry = CreatePantry("Tuffy's Pantry");
  // ======================================================
  // 3. Predict what this prints out.
  //    Then uncomment the line below, and run main to check.
  //    Your prediction: 1
  std::cout << tuffys_pantry.use_count() << std::endl;

  // =================== YOUR CODE HERE ===================
  // 4. Assign the Volunteers `jc` and `paul` to the
  //    tuffys_pantry using the AssignToPantry function.
  // ======================================================
  jc.AssignToPantry(tuffys_pantry);
  paul.AssignToPantry(tuffys_pantry);
  // 5. Predict what this prints out then uncomment the line below
  //    and run main to check your prediction: 3
  std::cout << tuffys_pantry.use_count() << std::endl;

  // If you're here, uncomment the two lines of code below!
  jc.AssignedPantry()->Donate("Mango", 5);
  paul.AssignedPantry()->Donate("Mango", 20);

  // 6. Predict what this prints out.
  //    Look in the foodpantry.h file to see what it does.
  //    Then uncomment the line below, and run main to check.
  //    Your prediction: 25
  tuffys_pantry->DisplayPantryItems();
  // =================== YOUR CODE HERE ===================
  // 7. Call CreatePantry and create a new shared_ptr
  //    representing a different pantry location.
  //    Assign `jc` and `paul` to the new pantry.
  // ======================================================
  std::shared_ptr<FoodPantry> new_pantry = CreatePantry("New Pantry");

  jc.AssignToPantry(new_pantry);
  paul.AssignToPantry(new_pantry);
  // 8. Predict what this prints out.
  //    Then uncomment the line below, and run main to check.
  //    Your prediction: 1
  std::cout << tuffys_pantry.use_count() << std::endl;
  // 9. Predict what this prints out.
  //    Then uncomment the lines below, and run main to check.
  //    Your prediction: 0
  tuffys_pantry = nullptr;
  std::cout << tuffys_pantry.use_count() << std::endl;
}
