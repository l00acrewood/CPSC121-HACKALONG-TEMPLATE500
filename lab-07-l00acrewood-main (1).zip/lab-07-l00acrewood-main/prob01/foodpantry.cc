#include "foodpantry.h"

std::shared_ptr<FoodPantry> CreatePantry(const std::string &pantry_name) {
  return std::make_shared<FoodPantry>(pantry_name);
}