
from gggg import *

a = Assignment(12 , 4)
s = State(a)

horizontal_rule()

s.reject_if_file_unchanged('main.cc',
                           '7551a7bd4eed3e38575dfc254a7d0f1358fb6dbd573618ef78e09e1c58ca3289')
s.reject_if_file_unchanged('foodpantry.h',
                           '86e3584b9a25c6335ad719e3dd32ac60d39d8212e813438e450a2e547119bcc9')

s.reject_if_file_changed('tools/settings/unittest.cc',
                         '1ba34598c1fd04eb741501014e5b155d1055936086733553b466adc305487e85')

s.gtest_run('tools/output/unittest')
s.gtest_suite_test('CreateFoodPantry', 2)
s.gtest_suite_test('Driver', 8)

s.clang_tidy_run("main.cc", "main", ["foodpantry.cc"])
s.clang_tidy_check(1)

s.clang_format_run(["main.cc", "foodpantry.h", "volunteer.h", "foodpantry.cc"])
s.clang_format_check(1)

s.summarize()