#include <gmock/gmock.h>
#include <gtest/gtest.h>
#include <memory>
#include "../cppaudit/gtest_ext.h"
#include "../../foodpantry.h"

using ::testing::HasSubstr;
using ::testing::ContainsRegex;

TEST(CreateFoodPantry, CreateInHeap) {
  std::shared_ptr<FoodPantry> pantry = CreatePantry("My Pantry");
  ASSERT_NE(pantry, nullptr);
  ASSERT_EQ(pantry->GetName(), "My Pantry");
}

TEST(Driver, InitialCount) {
  ASSERT_EXECTHAT("main", "", HasSubstr("1")) << "Initial pantry count should be 1.";  
}
TEST(Driver, PantryAssignment) {
  ASSERT_EXECTHAT("main", "", HasSubstr("Assigned JC to Tuffy's Pantry")) << "JC should be assigned to Tuffy's Pantry.";  
  ASSERT_EXECTHAT("main", "", HasSubstr("Assigned Paul to Tuffy's Pantry")) << "Paul should be assigned to Tuffy's Pantry.";  
}
TEST(Driver, AddPointers) {
  ASSERT_EXECTHAT("main", "", HasSubstr("3")) << "Three pointers should point to Tuffy Pantry.";  
}

TEST(Driver, SharedPantryDonation) {
  ASSERT_EXECTHAT("main", "", HasSubstr("25 Mango")) << "Donations should be made to the same FoodPantry object (via JC and Paul).";  
}

TEST(Driver, NewPantryAssignment) {
  ASSERT_EXECTHAT("main", "", ContainsRegex("Assigned JC to(.|\n)*Assigned JC to")) << "JC should be reassigned to a new pantry.";  
  ASSERT_EXECTHAT("main", "", ContainsRegex("Assigned Paul to(.|\n)*Assigned Paul to")) << "Paul should reassigned to a new pantry.";  
}

TEST(Driver, ReducePantryCount) {
  ASSERT_EXECTHAT("main", "", ContainsRegex("1(.|\n)*1")) << "Pantry count should reduce to 1 after reassigning JC and Paul.";
}

TEST(Driver, DeallocateFoodPantry) {
  ASSERT_EXECTHAT("main", "", ContainsRegex(".*0(\\s|\n)*$")) << "Pantry count should reduce to 0 after setting tuffy_pantry to nullptr.";
}


int main(int argc, char **argv) {
  testing::InitGoogleTest(&argc, argv);    
  ::testing::UnitTest::GetInstance()->listeners().Append(new SkipListener());
  return RUN_ALL_TESTS();
}
